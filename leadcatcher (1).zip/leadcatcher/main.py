import io
import os
import re
import sqlite3
from datetime import datetime, timezone
from typing import Literal, Optional
from zoneinfo import ZoneInfo

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, StreamingResponse
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from pydantic import BaseModel

from messenger import BUSINESS_NAME, build_message, send_message

DB_FILE = os.getenv("DB_FILE", "leads.db")
TIMEZONE = ZoneInfo(os.getenv("BUSINESS_TZ", "Asia/Karachi"))

app = FastAPI(title="LeadCatcher")


# ---------- Database ----------
def db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as conn:
        conn.execute(
            """CREATE TABLE IF NOT EXISTS leads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT DEFAULT '',
                contact TEXT NOT NULL,
                channel TEXT NOT NULL,
                note TEXT DEFAULT '',
                status TEXT NOT NULL DEFAULT 'waiting',
                message_sent TEXT DEFAULT '',
                delivery TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                replied_at TEXT
            )"""
        )


init_db()


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ---------- Data shapes ----------
class LeadIn(BaseModel):
    name: str = ""
    contact: str
    channel: Literal["call", "sms", "email"]
    note: str = ""


class ReplyIn(BaseModel):
    message: Optional[str] = None  # leave empty to use the default polite message


def check_contact(contact: str, channel: str) -> str:
    contact = contact.strip()
    if channel == "email":
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", contact):
            raise HTTPException(422, "Enter a valid email address, like name@example.com")
    else:
        digits = re.sub(r"\D", "", contact)
        if len(digits) < 7:
            raise HTTPException(422, "Enter a valid phone number, like +923001234567")
    return contact


def get_lead(conn, lead_id: int):
    row = conn.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Lead not found")
    return row


def reply_to(conn, row, message: Optional[str]) -> str:
    text = (message or "").strip() or build_message(row["name"], row["channel"])
    try:
        delivery = send_message(row["contact"], row["channel"], text)
    except Exception as e:
        raise HTTPException(502, f"Could not send the message: {e}")
    conn.execute(
        "UPDATE leads SET status='replied', message_sent=?, delivery=?, replied_at=? WHERE id=?",
        (text, delivery, now(), row["id"]),
    )
    return delivery


# ---------- API ----------
@app.get("/api/config")
def config():
    return {"business": BUSINESS_NAME}


@app.get("/api/leads")
def list_leads():
    with db() as conn:
        rows = conn.execute("SELECT * FROM leads ORDER BY id DESC").fetchall()
    return [dict(r) for r in rows]


@app.post("/api/leads", status_code=201)
def add_lead(lead: LeadIn):
    contact = check_contact(lead.contact, lead.channel)
    with db() as conn:
        cur = conn.execute(
            "INSERT INTO leads (name, contact, channel, note, created_at) VALUES (?,?,?,?,?)",
            (lead.name.strip(), contact, lead.channel, lead.note.strip(), now()),
        )
        return dict(get_lead(conn, cur.lastrowid))


@app.get("/api/preview/{lead_id}")
def preview(lead_id: int):
    with db() as conn:
        row = get_lead(conn, lead_id)
    return {"message": build_message(row["name"], row["channel"])}


@app.post("/api/leads/{lead_id}/reply")
def reply(lead_id: int, body: ReplyIn):
    with db() as conn:
        row = get_lead(conn, lead_id)
        if row["status"] == "replied":
            raise HTTPException(409, "This lead already got a reply")
        delivery = reply_to(conn, row, body.message)
    return {"delivery": delivery}


@app.post("/api/reply-all")
def reply_all():
    sent, failed = 0, 0
    with db() as conn:
        waiting = conn.execute("SELECT * FROM leads WHERE status='waiting'").fetchall()
        for row in waiting:
            try:
                reply_to(conn, row, None)
                sent += 1
            except HTTPException:
                failed += 1
    return {"sent": sent, "failed": failed}


@app.delete("/api/leads/{lead_id}")
def delete_lead(lead_id: int):
    with db() as conn:
        get_lead(conn, lead_id)
        conn.execute("DELETE FROM leads WHERE id = ?", (lead_id,))
    return {"deleted": lead_id}


@app.get("/api/export")
def export_excel():
    with db() as conn:
        rows = conn.execute("SELECT * FROM leads ORDER BY id DESC").fetchall()

    def local(ts):
        if not ts:
            return ""
        return datetime.fromisoformat(ts).astimezone(TIMEZONE).strftime("%Y-%m-%d %H:%M")

    channel_names = {"call": "Missed call", "sms": "Missed SMS", "email": "Missed email"}
    wb = Workbook()
    ws = wb.active
    ws.title = "Leads"
    headers = ["ID", "Name", "Contact", "How they reached us", "Note", "Status",
               "Received", "Replied", "Message sent", "Delivery"]
    ws.append(headers)
    for r in rows:
        ws.append([
            r["id"], r["name"], r["contact"], channel_names[r["channel"]], r["note"],
            "Replied" if r["status"] == "replied" else "Waiting",
            local(r["created_at"]), local(r["replied_at"]), r["message_sent"], r["delivery"],
        ])

    head_fill = PatternFill("solid", fgColor="12202A")
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = head_fill
    for col, width in zip("ABCDEFGHIJ", [6, 20, 26, 20, 36, 10, 17, 17, 60, 11]):
        ws.column_dimensions[col].width = width
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    ws.freeze_panes = "A2"

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    filename = f"leads-{datetime.now(TIMEZONE).strftime('%Y-%m-%d')}.xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ---------- Frontend ----------
@app.get("/")
def home():
    return FileResponse("static/index.html")
