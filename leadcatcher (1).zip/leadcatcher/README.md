# LeadCatcher

Track leads your business missed (calls, SMS, emails), send polite follow-ups,
and download everything as an Excel file.

## Run it (GitHub Codespaces)

    pip install -r requirements.txt
    BUSINESS_NAME="Your Business Name" uvicorn main:app --reload

Codespaces shows a popup "Open in Browser" for port 8000. Click it.
Interactive API docs: add /docs to the URL.

## Files

    main.py           the API + Excel export (FastAPI + SQLite)
    messenger.py      polite message templates + sending
    static/index.html the whole frontend
    leads.db          created automatically, your saved records

## Test mode vs real sending

By default replies are "simulated": saved in the database, nothing is sent.
To send for real, set environment variables before starting the server:

    Email: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD
    SMS:   TWILIO_SID, TWILIO_TOKEN, TWILIO_FROM

Optional: BUSINESS_TZ (default Asia/Karachi) sets the time zone used in Excel.
