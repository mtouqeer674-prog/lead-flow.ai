"""
Builds polite follow-up messages and sends them.

Sending works like this:
  - Email  -> real send if SMTP_* settings exist, otherwise simulated
  - Call / SMS -> real SMS if TWILIO_* settings exist, otherwise simulated

"Simulated" means we only record the message in the database. This lets you
test the whole app safely before connecting real accounts.
"""
import base64
import os
import smtplib
import urllib.parse
import urllib.request
from email.message import EmailMessage

BUSINESS_NAME = os.getenv("BUSINESS_NAME", "Our Business")

TEMPLATES = {
    "call": (
        "Hi {name}, sorry we missed your call at {business}. "
        "We'd love to help. Reply here with what you need, "
        "or tell us a good time and we'll call you back."
    ),
    "sms": (
        "Hi {name}, thank you for messaging {business}, and sorry for the delay. "
        "How can we help you? Reply here and we'll get back to you right away."
    ),
    "email": (
        "Hi {name},\n\n"
        "Thank you for contacting {business}, and sorry we missed your message. "
        "We'd be glad to help. Please reply with a few details, "
        "or let us know a good time for a quick call.\n\n"
        "Kind regards,\n{business}"
    ),
}


def build_message(name: str, channel: str) -> str:
    return TEMPLATES[channel].format(name=name or "there", business=BUSINESS_NAME)


def send_message(contact: str, channel: str, text: str) -> str:
    """Returns 'sent' (really delivered) or 'simulated'. Raises on failure."""
    if channel == "email":
        if os.getenv("SMTP_HOST"):
            _send_email(contact, text)
            return "sent"
        return "simulated"

    if os.getenv("TWILIO_SID"):
        _send_sms(contact, text)
        return "sent"
    return "simulated"


def _send_email(to: str, text: str) -> None:
    msg = EmailMessage()
    msg["Subject"] = f"Sorry we missed you - {BUSINESS_NAME}"
    msg["From"] = os.getenv("SMTP_USER")
    msg["To"] = to
    msg.set_content(text)
    with smtplib.SMTP(os.environ["SMTP_HOST"], int(os.getenv("SMTP_PORT", "587"))) as s:
        s.starttls()
        s.login(os.environ["SMTP_USER"], os.environ["SMTP_PASSWORD"])
        s.send_message(msg)


def _send_sms(to: str, text: str) -> None:
    sid, token = os.environ["TWILIO_SID"], os.environ["TWILIO_TOKEN"]
    url = f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json"
    data = urllib.parse.urlencode(
        {"To": to, "From": os.environ["TWILIO_FROM"], "Body": text}
    ).encode()
    req = urllib.request.Request(url, data=data)
    auth = base64.b64encode(f"{sid}:{token}".encode()).decode()
    req.add_header("Authorization", f"Basic {auth}")
    urllib.request.urlopen(req, timeout=15).read()
